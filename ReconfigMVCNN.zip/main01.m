clearvars; close all; clc;

params.numViews = 2;
params.imageSize = [224 224 3];
params.numClasses = 2;
params.levels = logical([0 0 0 0]);
net = multiResNet18(params);
analyzeNetwork(net);

