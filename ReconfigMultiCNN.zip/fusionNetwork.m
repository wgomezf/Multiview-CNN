% Serial convolutional block
function [net,con] = fusionNetwork(net,params)
numBranches = params.numViews;
[fusionPoints,filterSize,numFiltersIn,numFiltersOut] = getFusionPoints(params);
for i = 1:numel(numFiltersIn)
    blk = fusionBlock(i,numBranches,numFiltersIn(i),numFiltersOut(i),filterSize(i),filterSize(end));
    net = addLayers(net,blk);
end
if sum(params.levels) > 0
    layers = [depthConcatenationLayer(sum(params.levels)+1,'Name','concat')
              globalAveragePooling2dLayer('Name','avg_pool')
              fullyConnectedLayer(2,'Name','fc')
              softmaxLayer('Name', 'softmax')];
else
    layers = [globalAveragePooling2dLayer('Name','avg_pool')
              fullyConnectedLayer(2,'Name','fc')
              softmaxLayer('Name', 'softmax')];
end
net = addLayers(net,layers);
con = cell(numBranches*numel(fusionPoints)+numel(fusionPoints),2);
k = 1;
for i = 1:numBranches
    for j = 1:numel(fusionPoints)
        con{k,1} = sprintf('%s_%d',fusionPoints(j,:),i);
        con{k,2} = sprintf('cat_Fusion%d/in%d',j,i);
        k = k+1;
    end
end
if sum(params.levels) > 0
    for i = 1:numel(fusionPoints)
        con{k,1} = sprintf('pool_Fusion%d',i);
        con{k,2} = sprintf('concat/in%d',i);
        k = k+1;
    end
else
    con{k,1} = sprintf('pool_Fusion%d',1);
    con{k,2} = sprintf('avg_pool');
end
%**************************************************************************
% Serial convolutional block
function layers = fusionBlock(level,numInputs,numFiltersIn,numFiltersOut,inputSize,outputSize)
stride = inputSize/outputSize;
poolSize = inputSize - (outputSize-1)*stride;
layers = [depthConcatenationLayer(numInputs,'Name',sprintf('cat_Fusion%d',level))
          convolution2dLayer(1,numFiltersIn,'Padding','same','Name',sprintf('conv1_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          batchNormalizationLayer('Name',sprintf('bn1_Fusion%d',level))
          reluLayer('Name',sprintf('relu1_Fusion%d',level))
          convolution2dLayer(3,numFiltersOut,'Padding','same','Name',sprintf('conv2_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          batchNormalizationLayer('Name',sprintf('bn2_Fusion%d',level))
          reluLayer('Name',sprintf('relu2_Fusion%d',level))
          maxPooling2dLayer(poolSize,'Stride',stride,'Name',sprintf('pool_Fusion%d',level))];
