clearvars; close all; clc;

params.numViews = 2;                % Number of views
params.imageSize = [224 224 3];     % Input image size
params.numClasses = 2;              % Number of classes
params.levels = logical([0 0 0 0]); % Configuration: 0-OFF and 1-ON
net = multiResNet18(params);        % Create the network
analyzeNetwork(net);                % Show the architecture

