function [fusionPoints,filterSize,filterIn,filterOut] = getFusionPoints(params)
numBranches = params.numViews;
fusionPoints = ["conv1_relu";"res2b_relu";"res3b_relu";"res4b_relu";"res5b_relu"];
fusionPoints = fusionPoints(cat(2,params.levels,true));
net = imagePretrainedNetwork('resnet18');
info = analyzeNetwork(net,'Plot','none');
lNames = info.LayerInfo.Name;
lSizes = info.LayerInfo.ActivationSizes;
filterIn = zeros(numel(fusionPoints),1);
filterOut = zeros(numel(fusionPoints),1);
for i = 1:numel(lNames)
    for j = 1:numel(fusionPoints)
        if strcmpi(lNames(i),fusionPoints(j))
            filterIn(j) = round(0.5*lSizes{i}(3)*numBranches);
            filterOut(j) = round(0.5*filterIn(j));%2^(numel(fusionPoints)-j+3);
        end
    end
end
%filterOut = 2.^((numel(fusionPoints):-1:1)+2);
id  = contains(lNames,fusionPoints);
aux = lSizes(id);
val = cat(1,aux{:});
filterSize = val(:,1);