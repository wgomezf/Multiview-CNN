function net = multiResNet18(params)
numViews = params.numViews;
con = cell(1,numViews+1);
net = layerGraph();
for i = 1:numViews
    [aux,con{i}] = getResNet18(i);
    for j = 1:size(aux.Layers,1)
        layer = getLayer(aux,aux.Layers(j).Name);
        net = addLayers(net,layer);
    end
end
[net,con{numViews+1}] = fusionNetwork(net,params);
for i = 1:numViews+1
    for j = 1:size(con{i},1)
        net = connectLayers(net,con{i}{j,1},con{i}{j,2});
    end
end
net = dlnetwork(net);
