function net = multiResNet18(numClasses,numViews,block)
net = layerGraph();
con = cell(1,numViews+1);
for i = 1:numViews
    [aux,con{i}] = getResNet18(i);
    for j = 1:size(aux.Layers,1)
        layer = getLayer(aux,aux.Layers(j).Name);
        net = addLayers(net,layer);
    end
end
if strcmpi(block,'serial')
    [net,con{i+1}] = SerialFusionLayer(net,numViews,numClasses);
elseif strcmpi(block,'resnet')
    [net,con{i+1}] = ResNetFusionLayer(net,numViews,numClasses);
else
    error('Unknown fusion block!');
end
for i = 1:numViews+1
    for j = 1:size(con{i},1)
        net = connectLayers(net,con{i}{j,1},con{i}{j,2});
    end
end
net = dlnetwork(net);