% Serial convolutional block
function [net,con] = SerialFusionLayer(net,numBranches,numClasses)
[fusionPoints,sze,numFiltersIn] = getFusionPoints();
numFiltersOut = 2.^((numel(sze):-1:1)+2);
for i = 1:numel(sze)
    blk = fusionBlock(i,numBranches,numFiltersIn(i),numFiltersOut(i),sze(i),sze(end));
    net = addLayers(net,blk);
end
layers = [depthConcatenationLayer(numel(sze),'Name','concat')
          globalAveragePooling2dLayer('Name','avg_pool')
          dropoutLayer('Name','drop')
          fullyConnectedLayer(numClasses,'Name','fc','WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          softmaxLayer('Name', 'softmax')];
net = addLayers(net,layers);
con = cell(numBranches*numel(fusionPoints)+numel(fusionPoints),2);
k = 1;
for i = 1:numBranches
    for j = 1:numel(fusionPoints)
        con{k,1} = sprintf('%s_%d',fusionPoints(j,:),i);
        con{k,2} = sprintf('cat_Fusion%d/in%d',j,i);
        k = k+1;
    end
end
for i = 1:numel(fusionPoints)
    con{k,1} = sprintf('pool_Fusion%d',i);
    con{k,2} = sprintf('concat/in%d',i);
    k = k+1;
end
%**************************************************************************
% Serial convolutional block
function layers = fusionBlock(level,numInputs,numFiltersIn,numFiltersOut,inputSize,outputSize)
stride = inputSize/outputSize;
poolSize = inputSize - (outputSize-1)*stride;
%additionLayer(numInputs,'Name',sprintf('cat_Fusion%d',level))
layers = [depthConcatenationLayer(numInputs,'Name',sprintf('cat_Fusion%d',level))
          convolution2dLayer(1,numFiltersIn/2,'Padding','same','Name',sprintf('conv1_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          batchNormalizationLayer('Name',sprintf('bn1_Fusion%d',level))
          reluLayer('Name',sprintf('relu1_Fusion%d',level))
          convolution2dLayer(3,numFiltersOut,'Padding','same','Name',sprintf('conv2_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          batchNormalizationLayer('Name',sprintf('bn2_Fusion%d',level))
          reluLayer('Name',sprintf('relu2_Fusion%d',level))
          maxPooling2dLayer(poolSize,'Stride',stride,'Name',sprintf('pool_Fusion%d',level))];
%**************************************************************************
function [fusionPoints,sze,flt] = getFusionPoints()
fusionPoints = ["res2b_relu";"res3b_relu";"res4b_relu";"res5b_relu"];
net = imagePretrainedNetwork('resnet18');
info = analyzeNetwork(net,'Plot','none');
lNames = info.LayerInfo.Name;
lSizes = info.LayerInfo.ActivationSizes;
id = contains(lNames,fusionPoints);
aux = lSizes(id);
val = cat(1,aux{:});
sze = val(:,1);
flt = val(:,3);