% This demo function shows how to build a multi-view convolutional neural 
% network for classifying breast tumors into benign and malignant classes. 
% Before running this demo, download and install the ResNet18 network 
% (https://www.mathworks.com/matlabcentral/fileexchange/68261-deep-learning-toolbox-model-for-resnet-18-network). 
% All the functions were developed and tested in Matlab 2024b.

clearvars; close all; clc;

numClasses = 2;   % Number of classes (benign and malignant)
numViews = 3;     % Number of views: 1, 2 or 3
block = 'serial'; % Fusion block type: serial or resnet

if numViews > 1
    net = multiResNet18(numClasses,numViews,block);
else
    net = singleResNet18(numClasses);
end

analyzeNetwork(net);