% Residual block
function [net,con] = ResNetFusionLayer(net,numBranches,numClasses)
[fusionPoints,sze,numFiltersIn,numFiltersOut] = getFusionPoints();
bcon = cell(numel(sze),1);
for i = 1:numel(sze)
    [blk,bcon{i}] = fusionBlock(i,numBranches,numFiltersIn(i),numFiltersOut(i),sze(i),sze(end));
    for j = 1:size(blk.Layers,1)
        layer = getLayer(blk,blk.Layers(j).Name);
        net = addLayers(net,layer);
    end
end
bcon = cat(1,bcon{:});
layers = [depthConcatenationLayer(numel(sze),'Name','concat')
          globalAveragePooling2dLayer('Name','avg_pool')
          dropoutLayer('Name','drop')
          fullyConnectedLayer(numClasses,'Name','fc','WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
          softmaxLayer('Name', 'softmax')];
net = addLayers(net,layers);
con = cell(numBranches*numel(fusionPoints)+numel(fusionPoints)+size(bcon,1),2);
k = 1;
for i = 1:numBranches
    for j = 1:numel(fusionPoints)
        con{k,1} = sprintf('%s_%d',fusionPoints(j,:),i);
        con{k,2} = sprintf('cat_Fusion%d/in%d',j,i);
        k = k+1;
    end
end
for i = 1:numel(fusionPoints)
    con{k,1} = sprintf('pool_Fusion%d',i);
    con{k,2} = sprintf('concat/in%d',i);
    k = k+1;
end
for i = 1:size(bcon,1)
    con{k,1} = bcon{i,1};
    con{k,2} = bcon{i,2};
    k = k+1;
end
%**************************************************************************
% Residual block with convolutional skip and bottleneck
function [layers,con] = fusionBlock(level,numInputs,numFiltersIn,numFiltersOut,inputSize,outputSize)
stride   = inputSize/outputSize;
poolSize = inputSize - (outputSize-1)*stride;
layers   = layerGraph();
input = depthConcatenationLayer(numInputs,'Name',sprintf('cat_Fusion%d',level));
%input = additionLayer(numInputs,'Name',sprintf('cat_Fusion%d',level));
lft = [convolution2dLayer(1,numFiltersIn/2,'Padding','same','Name',sprintf('conv1_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
       batchNormalizationLayer('Name',sprintf('bn1_Fusion%d',level))
       reluLayer('Name',sprintf('relu1_Fusion%d',level))
       convolution2dLayer(3,numFiltersIn/2,'Padding','same','Name',sprintf('conv2_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
       batchNormalizationLayer('Name',sprintf('bn2_Fusion%d',level))
       reluLayer('Name',sprintf('relu2_Fusion%d',level))
       convolution2dLayer(1,numFiltersOut,'Padding','same','Name',sprintf('conv3_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
       batchNormalizationLayer('Name',sprintf('bn3_Fusion%d',level))];  
rgt = [convolution2dLayer(1,numFiltersOut,'Padding','same','Name',sprintf('conv4_Fusion%d',level),'WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
       batchNormalizationLayer('Name',sprintf('bn4_Fusion%d',level))];
output = [additionLayer(2,'Name',sprintf('add_Fusion%d',level))
          reluLayer('Name',sprintf('relu_Fusion%d',level))
          maxPooling2dLayer(poolSize,'Stride',stride,'Name',sprintf('pool_Fusion%d',level))];
layers = addLayers(layers,input);
layers = addLayers(layers,lft);
layers = addLayers(layers,rgt);
layers = addLayers(layers,output);
layers = connectLayers(layers,sprintf('cat_Fusion%d',level),sprintf('conv1_Fusion%d',level));
layers = connectLayers(layers,sprintf('cat_Fusion%d',level),sprintf('conv4_Fusion%d',level));
layers = connectLayers(layers,sprintf('bn3_Fusion%d',level),sprintf('add_Fusion%d/in1',level));
layers = connectLayers(layers,sprintf('bn4_Fusion%d',level),sprintf('add_Fusion%d/in2',level));
con = table2cell(layers.Connections);
layers = networkLayer(layers.Layers);
layers = layers.Network;
%****************************************************************************
function [fusionPoints,sze,filterIn,filterOut] = getFusionPoints()
fusionPoints = ["res2b_relu";"res3b_relu";"res4b_relu";"res5b_relu"];
net = imagePretrainedNetwork('resnet18');
info = analyzeNetwork(net,'Plot','none');
lNames = info.LayerInfo.Name;
lSizes = info.LayerInfo.ActivationSizes;
id = contains(lNames,fusionPoints);
aux = lSizes(id);
val = cat(1,aux{:});
sze = val(:,1);
%flt = val(:,3);
filterIn = val(:,3);
filterIn(2:end) = (3*val(2:end,3))/2;
filterOut = 2.^(log2(val(:,3))+1);