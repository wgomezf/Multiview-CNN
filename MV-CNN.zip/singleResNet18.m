function lgraph = singleResNet18(numClasses)
lgraph = imagePretrainedNetwork('resnet18');
lgraph = removeLayers(lgraph,{'fc1000','prob'});
layers = [fullyConnectedLayer(numClasses,'Name','fc2','WeightLearnRateFactor',10,'BiasLearnRateFactor',10);
          softmaxLayer('Name', 'softmax')];
lgraph = addLayers(lgraph,layers);
lgraph = connectLayers(lgraph,'pool5','fc2');