function [net,con] = getResNet18(branch)
net = imagePretrainedNetwork('resnet18');
net = removeLayers(net,{'pool5','fc1000','prob'});
app = sprintf('_%d',branch);
for i = 1:size(net.Layers,1)
    layer = getLayer(net,net.Layers(i).Name);
    layer.Name = append(layer.Name,app);
    net = replaceLayer(net,net.Layers(i).Name,layer);
end
con = table2cell(net.Connections);
